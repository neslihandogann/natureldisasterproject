package com.mycompany.natureldisaster

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
